-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 05 déc. 2020 à 17:21
-- Version du serveur :  10.4.8-MariaDB
-- Version de PHP :  7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `daary`
--

-- --------------------------------------------------------

--
-- Structure de la table `albums`
--

CREATE TABLE `albums` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `category_post`
--

CREATE TABLE `category_post` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `comments`
--

CREATE TABLE `comments` (
  `id` int(10) UNSIGNED NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `commentable_id` int(11) NOT NULL,
  `commentable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `parent` int(11) NOT NULL DEFAULT 0,
  `parent_id` int(11) DEFAULT NULL,
  `approved` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `favorites`
--

CREATE TABLE `favorites` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL COMMENT 'user_id',
  `favoriteable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `favoriteable_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `favorites`
--

INSERT INTO `favorites` (`id`, `user_id`, `favoriteable_type`, `favoriteable_id`, `created_at`, `updated_at`) VALUES
(4, 3, 'App\\Property', 1, '2020-12-04 16:05:41', '2020-12-04 16:05:41'),
(5, 3, 'App\\Property', 3, '2020-12-04 17:15:22', '2020-12-04 17:15:22');

-- --------------------------------------------------------

--
-- Structure de la table `features`
--

CREATE TABLE `features` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `features`
--

INSERT INTO `features` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Centre Ville', 'centre-ville', '2020-11-10 00:51:47', '2020-11-10 01:08:34'),
(2, 'Peripherique', 'peripherique', '2020-11-10 00:52:05', '2020-11-10 01:08:15'),
(3, 'Residentielle', 'residentielle', '2020-11-10 00:52:26', '2020-11-10 01:07:57');

-- --------------------------------------------------------

--
-- Structure de la table `feature_property`
--

CREATE TABLE `feature_property` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(11) NOT NULL,
  `feature_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `feature_property`
--

INSERT INTO `feature_property` (`id`, `property_id`, `feature_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '2020-11-10 00:57:18', '2020-11-10 00:57:18'),
(2, 2, 2, '2020-11-10 03:16:20', '2020-11-10 03:16:20');

-- --------------------------------------------------------

--
-- Structure de la table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `album_id` int(11) NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `agent_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `property_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `messages`
--

INSERT INTO `messages` (`id`, `agent_id`, `user_id`, `property_id`, `name`, `email`, `phone`, `message`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, 1, 1, 'Demba', 'demba94diagana@gmail.com', '41905065', 'salut c\'est à combien', 0, '2020-11-10 01:47:37', '2020-11-10 01:50:13');

-- --------------------------------------------------------

--
-- Structure de la table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_05_07_134045_create_roles_table', 1),
(4, '2018_05_09_054206_create_tags_table', 1),
(5, '2018_05_09_135424_create_categories_table', 1),
(6, '2018_05_10_171517_create_posts_table', 1),
(7, '2018_05_10_172731_create_category_post_table', 1),
(8, '2018_05_10_172800_create_post_tag_table', 1),
(9, '2018_05_19_134221_create_features_table', 1),
(10, '2018_05_19_134753_create_feature_property_table', 1),
(11, '2018_07_06_171008_create_property_image_galleries_table', 1),
(12, '2018_07_18_042846_create_galleries_table', 1),
(13, '2018_08_12_081814_create_sliders_table', 1),
(14, '2018_08_12_113108_create_testimonials_table', 1),
(15, '2018_08_12_142529_create_albums_table', 1),
(16, '2018_08_15_194359_create_messages_table', 1),
(17, '2018_08_20_070748_create_settings_table', 1),
(18, '2018_08_24_073322_create_properties_table', 1),
(19, '2018_08_25_110649_create_comments_table', 1),
(20, '2018_09_04_183409_create_ratings_table', 1),
(21, '2018_10_17_153558_create_services_table', 1),
(22, '2020_11_14_140319_change_column_password_to_users', 2),
(24, '2020_11_14_142232_add_column_to_table_users', 3),
(28, '2020_11_15_134516_change_column_size_to_table_users', 4),
(29, '2020_11_17_100808_add_column_user_id_to_table_properties', 5),
(38, '2020_04_04_000000_create_user_follower_table', 6),
(43, '2020_11_19_111625_add_column_phone_password_resets', 7),
(44, '2020_11_19_124650_add_columns_code', 8),
(46, '2020_11_24_152501_add_column_and_change_column', 9),
(48, '2020_11_29_141508_add_column_publish_to_properties', 10),
(49, '2020_12_02_124653_create_user_follower_table', 11),
(50, '2020_12_02_144624_create_user_favorites_table', 12),
(51, '2020_12_02_173821_add_column_user_id_to_properties', 13),
(52, '2018_12_14_000000_create_favorites_table', 14);

-- --------------------------------------------------------

--
-- Structure de la table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `password_resets`
--

INSERT INTO `password_resets` (`email`, `phone`, `token`, `created_at`) VALUES
('46809200', NULL, 'apCDeElpSoWAtn6rWdsnhusxugH5X4Si74YlSuDZ', '2020-11-19 17:14:30'),
(NULL, '46809200', 'nLYzzLHU3WWedat1EBixitX4nPzZ1t8ZneqZXIB2', '2020-11-19 18:51:19'),
(NULL, '37545828', 'DP9szewO6vDONIQULjnZ9dUKT6m9wDrVY6pMWiMr', '2020-11-19 19:18:36');

-- --------------------------------------------------------

--
-- Structure de la table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_count` int(11) NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `is_approved` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `post_tag`
--

CREATE TABLE `post_tag` (
  `id` int(10) UNSIGNED NOT NULL,
  `post_id` int(10) UNSIGNED NOT NULL,
  `tag_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `properties`
--

CREATE TABLE `properties` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `publish` tinyint(1) NOT NULL DEFAULT 1,
  `purpose` enum('Vendre','Louer') COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('Maison','Appartement') COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bedroom` int(11) NOT NULL,
  `bathroom` int(11) NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `area` int(11) NOT NULL,
  `agent_id` int(11) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `video` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `floor_plan` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nearby` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `properties`
--

INSERT INTO `properties` (`id`, `title`, `slug`, `price`, `featured`, `publish`, `purpose`, `type`, `image`, `bedroom`, `bathroom`, `city`, `city_slug`, `address`, `area`, `agent_id`, `user_id`, `description`, `video`, `floor_plan`, `location_latitude`, `location_longitude`, `nearby`, `created_at`, `updated_at`) VALUES
(1, 'Maison au tevragh-Zeina avec une piscine', 'maison-au-tevragh-zeina-avec-une-piscine', 4000.00, 0, 1, 'Vendre', 'Maison', 'maison-au-tevragh-zeina-avec-une-piscine-2020-11-10-5fa9e56d4a8e7.jpg', 8, 12, 'Nouakchott', 'nouakchott', 'Sebkha', 20000, 2, 0, 'Piscine pas loin de la page avec une belle vue', NULL, 'floor-plan-2020-11-10-5fa9e56d81872.jpg', '18.0858', '-15.9785', 'A coté de tirjik vacance', '2020-11-10 00:57:17', '2020-11-14 10:38:48'),
(2, 'Apparemment à louer à Dar Naim 16 Très calme', 'apparemment-a-louer-a-dar-naim-16-tres-calme', 1250.00, 1, 1, 'Louer', 'Appartement', 'apparemment-a-louer-a-dar-naim-16-tres-calme-2020-11-10-5faa06030e8d9.jpg', 5, 10, 'Kaedi', 'nouakchott', 'DarNaim', 40, 2, 0, 'Logement entier\r\nVous aurez le logement (appartement en résidence) rien que pour vous.\r\nNettoyage renforcé\r\nCet hôte s\'engage à appliquer le processus de nettoyage renforcé en 5 étapes d\'Airbnb.', NULL, 'floor-plan-2020-11-10-5faa0603f39a3.jpg', '39.7668', '-86.4013', 'Prison de Dar Naim', '2020-11-10 03:16:20', '2020-11-14 16:46:36'),
(3, 'Apparemment à louer à Tine Sweylim 16 Très calme', 'apparemment-a-louer-a-Tine-Swilem-16-tres-calme', 12500.00, 1, 1, 'Louer', 'Appartement', 'apparemment-a-louer-a-dar-naim-16-tres-calme-2020-11-10-5faa06030e8d9.jpg', 5, 10, 'Nouakchott', 'nouakchott', 'DarNaim', 40, 2, 0, 'Logement entier\r\nVous aurez le logement (appartement en résidence) rien que pour vous.\r\nNettoyage renforcé\r\nCet hôte s\'engage à appliquer le processus de nettoyage renforcé en 5 étapes d\'Airbnb.', NULL, 'floor-plan-2020-11-10-5faa0603f39a3.jpg', '39.7668', '-86.4013', 'Carrefour Tine Swiylim', '2020-11-10 03:16:20', '2020-11-14 16:46:36'),
(4, 'Maison a El-Mina avec un jardin', 'maison-a-el-mina-avec-un-jardin', 200500.00, 0, 1, 'Vendre', 'Maison', 'maison-a-el-mina-avec-un-jardin-2020-12-01-5fc6169e5caa9.jpg', 5, 6, 'Nouakchot', 'nouakchot', 'El-Mina', 32, 2, 0, 'Maison a El-Mina avec un jardinMaison a El-Mina avec un jardin Maison a El-Mina avec un jardin Maison a El-Mina avec un jardin Maison a El-Mina avec un jardin Maison a El-Mina avec un jardin Maison a El-Mina avec un jardin Maison a El-Mina avec un jardin Maison a El-Mina avec un jardin', NULL, 'floor-plan-2020-12-01-5fc6169f0b0a4.jpg', NULL, NULL, 'Prés du Marché', '2020-12-01 10:10:39', '2020-12-01 10:10:39');

-- --------------------------------------------------------

--
-- Structure de la table `property_image_galleries`
--

CREATE TABLE `property_image_galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `property_image_galleries`
--

INSERT INTO `property_image_galleries` (`id`, `property_id`, `name`, `size`, `created_at`, `updated_at`) VALUES
(3, 1, 'gallary-2020-11-10-5fa9ec4a51aa2.jpg', '436797', '2020-11-10 01:26:34', '2020-11-10 01:26:34'),
(4, 1, 'gallary-2020-11-10-5fa9ec4ad0a03.jpg', '593908', '2020-11-10 01:26:35', '2020-11-10 01:26:35'),
(5, 2, 'gallary-2020-11-10-5faa0604cc3e7.jpg', '250516', '2020-11-10 03:16:21', '2020-11-10 03:16:21'),
(6, 2, 'gallary-2020-11-10-5faa06052f14a.jpg', '165706', '2020-11-10 03:16:21', '2020-11-10 03:16:21');

-- --------------------------------------------------------

--
-- Structure de la table `ratings`
--

CREATE TABLE `ratings` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `rating` decimal(8,2) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `ratings`
--

INSERT INTO `ratings` (`id`, `user_id`, `property_id`, `rating`, `type`, `created_at`, `updated_at`) VALUES
(1, 2, 1, '4.50', 'property', '2020-11-10 03:55:58', '2020-11-10 03:55:58');

-- --------------------------------------------------------

--
-- Structure de la table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `roles`
--

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'admin', '2020-10-19 01:13:57', NULL),
(2, 'Agent', 'agent', '2020-10-19 01:13:57', NULL),
(3, 'User', 'user', '2020-10-19 01:13:57', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `services`
--

CREATE TABLE `services` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `service_order` int(11) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `footer` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `aboutus` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `facebook` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `twitter` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `linkedin` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `description`, `image`, `created_at`, `updated_at`) VALUES
(1, 'Appartement', 'Appartement au Tevragh Zeyna', 'appartement-2020-10-19-5f8cee5dd8767.jpg', '2020-10-19 01:39:43', '2020-10-19 01:39:43');

-- --------------------------------------------------------

--
-- Structure de la table `tags`
--

CREATE TABLE `tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `testimonial` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `about` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `isVerified` tinyint(1) NOT NULL DEFAULT 0,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `role_id`, `name`, `username`, `email`, `phone_number`, `image`, `provider`, `provider_id`, `about`, `isVerified`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Admin', 'admin', 'admin@admin.com', '+22220736688', 'admin-admin-1-2020-10-19.jpg', '', '', 'Bio of admin', 1, '$2y$10$ua1RRgeXxeRggry2bOoGdOiTutgkcTJwYUlgQbp8U8Wvcne7PNBnW', 'FoGBkbErMXit2rVrYtydTlg6JKccTThthVw4FqiTvQWDlPIlCFuW8gahwJJT', '2020-10-19 01:13:56', '2020-11-24 23:57:52'),
(2, 2, 'Agent', 'agent', 'agent@agent.com', '+22237545828', 'agent-agent-2-2020-11-10.png', '', '', NULL, 1, '$2y$10$fAgoXheuYZIEcwBdjieiqeJS8J16ueeikpv.6/bYhf40A.sVjd0mW', 'AAEKIWuPHyKm4OU9m2Gh5bcn44NX00cUDOhuHsRzMvQkvYL8pGxK5rL1QaZl', '2020-10-19 01:13:56', '2020-11-25 10:48:11'),
(3, 3, 'User', '1', 'user@user.com', '+22244451743', 'user-user-3-2020-12-04.png', '', '', NULL, 0, '$2y$10$JMIyXdRGdFNrwCQUy4OmtOAQk8Z8C1dDg5aagNher46C0cVVaQQV.', 'ds917M9tyrIg05iATBvBl6jsFNf6SUYQ9oTvyZ8CVK2Zcj9mvcLIc7VcSkN5', '2020-10-19 01:13:57', '2020-12-04 17:26:34'),
(4, 3, 'Demba', 'Demba', 'demba94diagana@gmail.com', '0000000000', 'default.png', '', '', NULL, 0, '$2y$10$ueJUwuFvm6UixF8y3kWRLuAFYFVJ1yGja/moclX/xIs8j.YL7GNG6', 'AxvZKbc1d5V5xX75kB69duLAgeOLxbzZ8MCHYSazyQI0Ar1X6FEzMWaUFCQY', '2020-11-13 10:17:01', '2020-11-13 10:17:01'),
(5, 3, 'niggaz', 'edyl', 'demba94diagana@daary.com', '77889966', 'default.png', '', '', NULL, 0, '$2y$10$5jurYMMF85p4euWfJL48.ewbNH7WDe0uCtpYTEY1H9/YBpOleuZWe', NULL, '2020-11-14 00:01:06', '2020-11-14 00:01:06'),
(6, 3, 'Edyl Diagana', 'Edyl Diagana', 'dembadiagana@live.fr', '10348412', 'https://graph.facebook.com/v3.3/3690214201037616/picture?access_token=EAAYol4VlzgMBAJecs1GulZAar9D3TegLBbjqYVvgQR55gZAjg9sX4MJhu6GCVgJZCqaHNs9XgHXlfWSLqIgQ8KnPgdl4HzlWZBMnAUcmEGVTeZApMMYzbYrrVxHZCHDtNEP6FrNmQBuqcF9spc8Vd6TXIXBoIfYxMwVkOeIvUurgZDZD&type=normal', 'facebook', '3690214201037616', NULL, 0, NULL, NULL, '2020-11-15 13:57:45', '2020-11-15 13:57:45'),
(7, 3, 'Edyl07', 'Edyl07', 'edyl@daary.com', '41616909', NULL, NULL, NULL, NULL, 0, '$2y$10$Bm0CNMmJZ/ga4sSO0VYMJOVqZCVqe6Q3J/WlyzjaphWIEB5BlFUP.', NULL, '2020-11-19 08:06:55', '2020-11-19 08:06:55'),
(8, 2, 'Test', 'Test', 'Test@daary.com', '+22241905565', NULL, NULL, NULL, NULL, 0, '$2y$10$Uc.boQIJ2gGiaCOyJw1S7edfar0V4Pl4uo/gfPy/cl8vIyr79juuO', NULL, '2020-11-25 16:03:10', '2020-11-25 16:03:10');

-- --------------------------------------------------------

--
-- Structure de la table `user_favorites`
--

CREATE TABLE `user_favorites` (
  `id` int(10) UNSIGNED NOT NULL,
  `property_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `albums`
--
ALTER TABLE `albums`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `category_post`
--
ALTER TABLE `category_post`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `favorites_favoriteable_type_favoriteable_id_index` (`favoriteable_type`,`favoriteable_id`),
  ADD KEY `favorites_user_id_index` (`user_id`);

--
-- Index pour la table `features`
--
ALTER TABLE `features`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `feature_property`
--
ALTER TABLE `feature_property`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_phone_index` (`phone`);

--
-- Index pour la table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `posts_slug_unique` (`slug`),
  ADD KEY `posts_user_id_foreign` (`user_id`);

--
-- Index pour la table `post_tag`
--
ALTER TABLE `post_tag`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `properties_slug_unique` (`slug`);

--
-- Index pour la table `property_image_galleries`
--
ALTER TABLE `property_image_galleries`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `tags`
--
ALTER TABLE `tags`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD UNIQUE KEY `phone` (`phone_number`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Index pour la table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_favorites_property_id_foreign` (`property_id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `albums`
--
ALTER TABLE `albums`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `category_post`
--
ALTER TABLE `category_post`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT pour la table `features`
--
ALTER TABLE `features`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `feature_property`
--
ALTER TABLE `feature_property`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT pour la table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `post_tag`
--
ALTER TABLE `post_tag`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pour la table `property_image_galleries`
--
ALTER TABLE `property_image_galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT pour la table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `tags`
--
ALTER TABLE `tags`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `user_favorites`
--
ALTER TABLE `user_favorites`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `user_favorites`
--
ALTER TABLE `user_favorites`
  ADD CONSTRAINT `user_favorites_property_id_foreign` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
